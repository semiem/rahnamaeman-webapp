package ir.avisaniot.sps;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.provider.Settings;
import android.util.Log;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.DataInput;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.net.URL;
import java.nio.ByteBuffer;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;
import java.util.concurrent.ExecutionException;

public class ConnectActivity extends AppCompatActivity {

    byte[] ConnectMessage;
    byte[] ResponseMessage;
    byte[] DoneMessage;
    String SSID = "", Pass = "", token = "", deviceName = "", mode = "",
            moduleResult = "", deviceRandomCode = "", deviceVersion = "", deviceSerial = "";
    int IDeviceRandomCode = 12345, IDeviceSerial = 32196622, IDeviceVersion = 11; //SERIAL= 32196622
    double x = 0.0d, y = 0.0d;
    private String TAG = "me";


    private byte[] CreateData(byte header, byte command, byte[] data) {
        short ml = (short) (data.length + 2);
        byte lLow = (byte) ((ml >> 0) & 0xFF);
        byte lHigh = (byte) ((ml >> 8) & 0xFF);

        //Calculate CRC
        byte crc = 0;
        crc += command;
        for (int i = 0; i < data.length; i++)
            crc += data[i];

        crc += lLow;
        crc += lHigh;

        ByteArrayOutputStream output = new ByteArrayOutputStream();
        try {
            output.write(header);
            output.write(lLow);
            output.write(lHigh);
            output.write(command);
            output.write(data);
            output.write(crc);
        } catch (IOException ex) {
            return null;
        }
        return output.toByteArray();
    }


    private static final char[] HEX_ARRAY = "0123456789ABCDEF".toCharArray();

    public static String bytesToHex(byte[] bytes) {
        char[] hexChars = new char[bytes.length * 2];
        for (int j = 0; j < bytes.length; j++) {
            int v = bytes[j] & 0xFF;
            hexChars[j * 2] = HEX_ARRAY[v >>> 4];
            hexChars[j * 2 + 1] = HEX_ARRAY[v & 0x0F];
        }
        return new String(hexChars);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_connect);

        Uri uri = getIntent().getData();
        if (uri != null) {
            SSID = uri.getQueryParameter("ssid");
            Pass = uri.getQueryParameter("pass");
            token = uri.getQueryParameter("token");
            x = Double.parseDouble(uri.getQueryParameter("x"));
            y = Double.parseDouble(uri.getQueryParameter("y"));
            deviceName = uri.getQueryParameter("deviceName");
            mode = uri.getQueryParameter("mode");


        } else {
            SSID = "PRFTech";
            Pass = "12345";
            token = "TEST";
            x = 0.0d;
            y = 0.0d;
            deviceName = "TEST";
            mode = "add";
//            mode = "change";
        }


//        String tst = "SSID=" + SSID + " ,Pass=" + Pass
//                + " ,token=" + token + " ,x=" + x + " ,y=" + y + " ,deviceName=" + deviceName;

//        ((TextView) findViewById(R.id.txtRandomCode)).setText(tst);

        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        try {
            byte[] bSSID = new byte[0];
            byte[] bPass = new byte[0];
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.KITKAT) {
                bSSID = SSID.getBytes(StandardCharsets.UTF_8);
                bPass = Pass.getBytes(StandardCharsets.UTF_8);
            }
            int bSSIDNBC = 64 - bSSID.length;
            int bPassNBC = 64 - bPass.length;

            byte[] bSSIDNB = new byte[bSSIDNBC];
            Arrays.fill(bSSIDNB, (byte) 0);
            byte[] bPassNB = new byte[bPassNBC];
            Arrays.fill(bPassNB, (byte) 0);

            byte[] cBSSID = new byte[bSSID.length + bSSIDNB.length];
            System.arraycopy(bSSID, 0, cBSSID, 0, bSSID.length);
            System.arraycopy(bSSIDNB, 0, cBSSID, bSSID.length, bSSIDNB.length);

            byte[] cBPass = new byte[bPass.length + bPassNB.length];
            System.arraycopy(bPass, 0, cBPass, 0, bPass.length);
            System.arraycopy(bPassNB, 0, cBPass, bPass.length, bPassNB.length);

            byte[] bNull = new byte[]{(byte) 0};
            baos.write(bNull);
            baos.write(cBSSID);
//            baos.write(bNull);
            baos.write(cBPass);
//            baos.write(bNull);
        } catch (Throwable e) {
            Toast.makeText(ConnectActivity.this, "مشکل در پارامتر های ارسالی", Toast.LENGTH_SHORT).show();
            finish();
        }

//        byte header = (byte) 0xFE;
//        byte[] data = {(byte)0x12, (byte)0x38, (byte)0xE0, (byte)0x90, (byte)0x03, (byte)0x63};
        byte[] data = baos.toByteArray();


//        byte[] TestMessage = CreateData((byte) 0xFE, (byte) 0x09,
//                new byte[] {(byte)0x12, (byte)0x38, (byte)0xE0, (byte)0x90, (byte)0x03, (byte)0x63});

        ConnectMessage = CreateData((byte) 0xFE, (byte) 0xF0, data);
        DoneMessage = CreateData((byte) 0xFE, (byte) 0xF1, new byte[]{0});
//        String s0 = bytesToHex(TestMessage);
//        String s1 = bytesToHex(ConnectMessage);
//        String s2 = bytesToHex(DoneMessage);
//        int me = 10;
//        new ConnectDataTask().execute();
//        sendPost(IDeviceSerial, IDeviceRandomCode, String.valueOf(IDeviceVersion), x, y, token, deviceName);


        findViewById(R.id.btnDoNext).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (moduleResult.isEmpty()) {
                    Toast.makeText(ConnectActivity.this, "اول باید پریز را به وای فای وصل کنید", Toast.LENGTH_SHORT).show();
                    new AlertDialog.Builder(ConnectActivity.this)
                            .setTitle("سوال")
                            .setMessage("آیا به هات اسپات پریز وصل هستید؟")
                            .setPositiveButton("بله", new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int which) {
                                    new ConnectDataTask().execute();
                                    ((TextView) findViewById(R.id.txtDoNext)).setText("لطفا صبر کنید");
                                }
                            })
                            .setNegativeButton("خیر", new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int which) {
                                    Toast.makeText(ConnectActivity.this, "لطفا به هات اسپات پریز وصل شوید", Toast.LENGTH_LONG).show();
                                    Intent openWirelessSettings = new Intent(Settings.ACTION_WIFI_SETTINGS);
                                    startActivity(openWirelessSettings);
                                }
                            })
                            .setIcon(android.R.drawable.ic_dialog_alert)
                            .show();
                } else {
                    Toast.makeText(ConnectActivity.this, "حال باید به اینترنت متصل باشید", Toast.LENGTH_SHORT).show();
                    new AlertDialog.Builder(ConnectActivity.this)
                            .setTitle("سوال")
                            .setMessage("آیا به اینترنت وصل هستید؟")
                            .setPositiveButton("بله", new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int which) {
                                    if (mode.equals("add")) {
                                        sendPost(IDeviceSerial, IDeviceRandomCode, String.valueOf(IDeviceVersion), x, y, token, deviceName);
                                    } else if (mode.equals("change")) {
                                        Intent intent = new Intent(ConnectActivity.this, MainActivity.class);
                                        startActivity(intent);
                                        finishAffinity();
                                    }
                                }
                            })
                            .setNegativeButton("خیر", new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int which) {
                                    Toast.makeText(ConnectActivity.this, "لطفا اینترنت متصل شوید", Toast.LENGTH_LONG).show();
                                    Intent openWirelessSettings = new Intent("android.settings.WIRELESS_SETTINGS");
                                    startActivity(openWirelessSettings);
                                }
                            })
                            .setIcon(android.R.drawable.ic_dialog_alert)
                            .show();
                }


            }
        });


    }

    public void sendPost(Integer SerialNumber, Integer RandomCode, String DeviceVersion,
                         Double X, Double Y, String Token, String DeviceName) {
        Thread thread = new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    URL url = new URL("https://sps.avisaniot.ir/api/CMD/");
                    HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                    conn.setRequestMethod("POST");
                    conn.setRequestProperty("Content-Type", "application/json;charset=UTF-8");
                    conn.setRequestProperty("Accept", "application/json");
                    conn.addRequestProperty("Authorization", "Bearer " + Token);

                    conn.setDoOutput(true);
                    conn.setDoInput(true);

                    JSONObject jsonParam = new JSONObject();
                    JSONArray Serial = new JSONArray();
                    Serial.put(SerialNumber);
                    jsonParam.put("Serial", Serial);
                    jsonParam.put("CommandNumber", 4);
                    JSONObject Data = new JSONObject();
                    Data.put("randomcode", RandomCode);
                    Data.put("version", DeviceVersion);
                    Data.put("deviceName", DeviceName);
                    Data.put("x", X);
                    Data.put("y", Y);
                    jsonParam.put("Data", Data);

//                    Log.i("JSON", jsonParam.toString());
                    DataOutputStream os = new DataOutputStream(conn.getOutputStream());
                    //os.writeBytes(URLEncoder.encode(jsonParam.toString(), "UTF-8"));
                    String jsonPar = jsonParam.toString();
                    os.writeBytes(jsonPar);

                    os.flush();
                    os.close();

//                    Log.i("STATUS", String.valueOf(conn.getResponseCode()));
//                    Log.i("MSG" , conn.getResponseMessage());

                    int code = conn.getResponseCode();
                    if (code != 200) {
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                Toast.makeText(ConnectActivity.this,
                                        "خطا، لطفا مجدد تلاش کنید." + String.valueOf(code),
                                        Toast.LENGTH_LONG).show();
                            }
                        });
                        conn.disconnect();
                        return;
                    } else {
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                Toast.makeText(ConnectActivity.this, "شما موفق شدید", Toast.LENGTH_LONG).show();
                            }
                        });
                        conn.disconnect();
                        Intent intent = new Intent(ConnectActivity.this, MainActivity.class);
                        startActivity(intent);
                        finishAffinity();
                    }


                } catch (Throwable e) {
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            ((TextView) findViewById(R.id.txtDoNext)).setText("خطا در ارسال داده به سرور\nلطفا مجدد تلاش کنید");
                        }
                    });
                    Log.d(TAG, e.getMessage());
                    e.printStackTrace();
                }
            }
        });

        thread.start();
    }

//    private Socket socket;
//
//    public void sendBytes(byte[] myByteArray) throws IOException {
//        sendBytes(myByteArray, 0, myByteArray.length);
//    }
//
//    public void sendBytes(byte[] myByteArray, int start, int len) throws IOException {
//        if (len < 0)
//            throw new IllegalArgumentException("Negative length not allowed");
//        if (start < 0 || start >= myByteArray.length)
//            throw new IndexOutOfBoundsException("Out of bounds: " + start);
//        // Other checks if needed.
//
//        // May be better to save the streams in the support class;
//        // just like the socket variable.
//        OutputStream out = socket.getOutputStream();
//        DataOutputStream dos = new DataOutputStream(out);
//
//        dos.writeInt(len);
//        if (len > 0) {
//            dos.write(myByteArray, start, len);
//        }
//    }
//
//    public byte[] readBytes() throws IOException {
//        // Again, probably better to store these objects references in the support class
//        InputStream in = socket.getInputStream();
//        DataInputStream dis = new DataInputStream(in);
//
//        int len = dis.readInt();
//        byte[] data = new byte[len];
//        if (len > 0) {
//            dis.readFully(data);
//        }
//        return data;
//    }

    byte[] receivedData;
    byte[] bDeviceSerial;
    byte[] bDeviceVersion;
    byte[] bDeviceRandomCode;

    String hReceivedData;
    String hDeviceSerial;
    String hDeviceVersion;
    String hDeviceRandomCode;

    public static int convertByteArrayToInt2(byte[] bytes) {
        int res = 0;
        int arrLen = bytes.length;
        for (int i = 0; i < arrLen; i++) {
            res |= (bytes[i] & 0xFF) << (arrLen - i - 1) * 8;
        }
        return res;
    }

    public static int toLittleEndian(final String hex) {
        int ret = 0;
        String hexLittleEndian = "";
        if (hex.length() % 2 != 0) return ret;
        for (int i = hex.length() - 2; i >= 0; i -= 2) {
            hexLittleEndian += hex.substring(i, i + 2);
        }
        ret = Integer.parseInt(hexLittleEndian, 16);
        return ret;
    }

    class ConnectDataTask extends AsyncTask<String, Void, Void> {
        ProgressDialog progress;

        @Override
        protected void onPreExecute() {
            progress = new ProgressDialog(ConnectActivity.this);
            progress.setMessage("در حال اتصال به پریز هوشمند\nلطفا کمی صبر کنید...");
            progress.setIndeterminate(true);
            progress.show();
        }

        @Override
        protected Void doInBackground(String... params) {
            Socket socket = new Socket();
//            String host = "192.168.43.252";
//            String host = "192.168.1.37";
            String host = "192.168.0.111";
            int port = 333;
            DataOutputStream s_out = null;
            //BufferedReader s_in = null;
            DataInputStream c_in = null;


            try {
                int timeout = 5 * 1000;
                socket.connect(new InetSocketAddress(host, port), timeout);

                s_out = new DataOutputStream(socket.getOutputStream());
                c_in = new DataInputStream(socket.getInputStream());
                //s_in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
                s_out.write(ConnectMessage);


                ByteArrayOutputStream arrivedData = new ByteArrayOutputStream();
                byte[] buffer = new byte[1024];
                int read = 0;

                int iHeader = c_in.read();
                int ilLow = c_in.read();
                int ilHigh = c_in.read();
                //int iCmd = c_in.read();

//                if(iHeader == -1)
//                    throw RuntimeException("Invalid Header");

                short dataLength = (short) (((ilHigh << 8) & 0xFF00) | ((ilLow << 0) & 0x00FF));

                int remainingData = dataLength;
                while ((read = c_in.read(buffer)) > 0) {
                    arrivedData.write(buffer, 0, read);
                    remainingData -= read;
                    if (remainingData == 0)
                        break;
                }

                receivedData = arrivedData.toByteArray();
//                byte iCmd = receivedData[0];
                bDeviceSerial = new byte[]{receivedData[2], receivedData[3], receivedData[4], receivedData[5]};
                bDeviceVersion = new byte[]{receivedData[6]};
                bDeviceRandomCode = new byte[]{receivedData[7], receivedData[8]};
                //result = "Successfully"+s_in.read();//s_in.readLine();


                deviceRandomCode = new String(bDeviceRandomCode);
                deviceVersion = new String(bDeviceVersion);
                deviceSerial = new String(bDeviceSerial);

//                IDeviceSerial = ByteBuffer.wrap(bDeviceSerial).getInt(); // big-endian by default
//                IDeviceVersion = ByteBuffer.wrap(bDeviceVersion).getInt();
//                IDeviceRandomCode = ByteBuffer.wrap(bDeviceRandomCode).getInt();

//                IDeviceSerial = convertByteArrayToInt2(bDeviceSerial);
//                IDeviceVersion = convertByteArrayToInt2(bDeviceVersion);
//                IDeviceRandomCode = convertByteArrayToInt2(bDeviceRandomCode);

                hReceivedData = bytesToHex(receivedData);
                hDeviceSerial = bytesToHex(bDeviceSerial);
                hDeviceVersion = bytesToHex(bDeviceVersion);
                hDeviceRandomCode = bytesToHex(bDeviceRandomCode);

                IDeviceSerial = toLittleEndian(hDeviceSerial);
                IDeviceVersion = toLittleEndian(hDeviceVersion);
                IDeviceRandomCode = toLittleEndian(hDeviceRandomCode);

                moduleResult = bytesToHex(receivedData);


                s_out.write(DoneMessage);
                socket.close();

                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
//                        Toast.makeText(ConnectActivity.this, "خطا در ارسال داده!", Toast.LENGTH_LONG).show();
                        Toast.makeText(ConnectActivity.this, moduleResult, Toast.LENGTH_LONG).show();
                    }
                });
                return null;

            } catch (Throwable e) {

                if (c_in != null) {
                    try {
                        c_in.close();
                        c_in = null;
                    } catch (IOException ioException) {
                    }
                }

                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
//                        Toast.makeText(ConnectActivity.this, "خطا در ارسال داده!", Toast.LENGTH_LONG).show();
                        Toast.makeText(ConnectActivity.this, e.getMessage(), Toast.LENGTH_LONG).show();
                    }
                });
                moduleResult = "";
                return null;
            }
//            Log.i(TAG, result);

        }

        @Override
        protected void onPostExecute(Void s) {
            if (progress.isShowing()) {
                progress.dismiss();
            }
            if (!moduleResult.isEmpty()) {
                Toast.makeText(ConnectActivity.this, "اتصال با موفقیت انجام شد", Toast.LENGTH_LONG).show();
                ((TextView) findViewById(R.id.txtDoNext)).setText("برای ادامه کلیک کنید");
//                ((TextView) findViewById(R.id.txtRD)).setText("HexDATA=" + hReceivedData);
//                ((TextView) findViewById(R.id.txtRandomCode)).setText("deviceRandomCode=" + String.valueOf(IDeviceRandomCode) + " ,hex=" + hDeviceRandomCode);
//                ((TextView) findViewById(R.id.txtVersion)).setText("deviceVersion=" + String.valueOf(IDeviceVersion) + " ,hex=" + hDeviceVersion);
//                ((TextView) findViewById(R.id.txtSerial)).setText("deviceSerial=" + String.valueOf(IDeviceSerial) + " ,hex=" + hDeviceSerial);
            } else {
                Toast.makeText(ConnectActivity.this, "لطفا مجددا تلاش کنید", Toast.LENGTH_LONG).show();
                ((TextView) findViewById(R.id.txtDoNext)).setText("لطفا مجددا تلاش کنید");
            }

//            Toast.makeText(ConnectActivity.this, "Connected " + s, Toast.LENGTH_SHORT).show();
//            tv.setText(s);
        }
    }

}